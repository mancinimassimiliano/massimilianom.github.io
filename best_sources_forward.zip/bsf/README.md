This is a first release of the code for the paper "Best Sources Forward: Domain Generalization Through Source-Specific Nets" (ICIP 2018). 

The implementation has been done using the Caffe framework (https://github.com/BVLC/caffe). This first realease contains the prototxt and the solver used for the PACS experiment.

The .zip contains the prototxts used for obtaining the results on the PACS experiments ("Ours" of Table 2) for our fully fine-tuned architecture. On the model prototxt there are some comments (preceded by #MM) that should:
1) clarify the implementation
2) point out to relevant part of the prototxts that must be changed. 

I used the bvlc_alexent (https://github.com/BVLC/caffe/tree/master/models/bvlc_alexnet) for initializing the network's parameters.

If you find this code useful, please cite:

@inProceedings{mancini2018best,
	author = {Mancini, Massimilano and Rota Bul\`o, Samuel and Caputo, Barbara and Ricci, Elisa},
  	title  = {Best sources forward: domain generalization through source-specific nets},
  	booktitle = {IEEE International Conference on Image Processing (ICIP)},
  	year      = {2018},
  	month     = {October}
}




